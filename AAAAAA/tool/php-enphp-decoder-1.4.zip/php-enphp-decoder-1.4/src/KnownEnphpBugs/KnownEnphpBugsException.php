<?php

namespace Ganlv\EnphpDecoder\KnownEnphpBugs;

use Exception;

abstract class KnownEnphpBugsException extends Exception
{
}
